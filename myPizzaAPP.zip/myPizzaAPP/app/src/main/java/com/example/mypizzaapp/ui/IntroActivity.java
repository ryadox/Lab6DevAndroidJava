package com.example.mypizzaapp.ui;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mypizzaapp.R;

public class IntroActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_splash);

        Thread launcher = new Thread(() -> {
            try {
                Thread.sleep(1800);
            } catch (Exception e) {}
            startActivity(new Intent(this, MainHubActivity.class));
            finish();
        });
        launcher.start();
    }
}
