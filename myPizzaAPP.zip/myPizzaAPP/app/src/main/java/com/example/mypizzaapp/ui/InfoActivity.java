package com.example.mypizzaapp.ui;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mypizzaapp.R;
import com.example.mypizzaapp.entity.PizzaItem;
import com.example.mypizzaapp.provider.DataStorage;

public class InfoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_details);

        long ref = getIntent().getLongExtra("target_id", -1);
        PizzaItem target = DataStorage.getManager().get(ref);

        ImageView hero = findViewById(R.id.heroImg);
        TextView title = findViewById(R.id.mainTitle);
        TextView stats = findViewById(R.id.statsTxt);
        TextView ingredients = findViewById(R.id.componentsTxt);
        TextView tutorial = findViewById(R.id.stepsTxt);

        if (target != null) {
            title.setText(target.getLabel());
            stats.setText(target.getTime() + " | Price: " + target.getCost() + " $");
            ingredients.setText(target.getComponents());
            tutorial.setText(target.getPreps());

            int resId = R.drawable.pizza_item_classic;
            if ("res_bbq".equals(target.getImgUrl())) resId = R.drawable.pizza_item_bbq;
            else if ("res_veg".equals(target.getImgUrl())) resId = R.drawable.pizza_item_veg;
            
            hero.setImageResource(resId);
        } else {
            title.setText("Error: Data lost!");
        }
    }
}
