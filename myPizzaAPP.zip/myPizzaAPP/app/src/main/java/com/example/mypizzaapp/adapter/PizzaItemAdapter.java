package com.example.mypizzaapp.adapter;

import android.content.Context;
import android.view.*;
import android.widget.*;
import com.example.mypizzaapp.R;
import com.example.mypizzaapp.entity.PizzaItem;
import java.util.List;

public class PizzaItemAdapter extends BaseAdapter {
    private final Context ctx;
    private final List<PizzaItem> items;

    public PizzaItemAdapter(Context ctx, List<PizzaItem> items) {
        this.ctx = ctx;
        this.items = items;
    }

    @Override public int getCount() { return items.size(); }
    @Override public Object getItem(int i) { return items.get(i); }
    @Override public long getItemId(int i) { return items.get(i).getUid(); }

    @Override
    public View getView(int p, View v, ViewGroup g) {
        if (v == null) v = LayoutInflater.from(ctx).inflate(R.layout.row_pizza, g, false);

        ImageView icon = v.findViewById(R.id.pizzaIcon);
        TextView title = v.findViewById(R.id.labelTxt);
        TextView sub = v.findViewById(R.id.subInfoTxt);

        PizzaItem item = items.get(p);
        title.setText(item.getLabel());
        sub.setText(item.getTime() + " | " + item.getCost() + " $");

        int resId = R.drawable.pizza_item_classic;
        if ("res_bbq".equals(item.getImgUrl())) resId = R.drawable.pizza_item_bbq;
        else if ("res_veg".equals(item.getImgUrl())) resId = R.drawable.pizza_item_veg;
        
        icon.setImageResource(resId);

        return v;
    }
}
