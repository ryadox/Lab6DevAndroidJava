package com.example.mypizzaapp.repo;

import java.util.List;

public interface BaseDao<T> {
    T add(T obj);
    T edit(T obj);
    boolean remove(long id);
    T get(long id);
    List<T> getAll();
}
