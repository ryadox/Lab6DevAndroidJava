package com.example.mypizzaapp.entity;

public class PizzaItem {
    private static long counter = 1;
    private long uid;
    private String label;
    private double cost;
    private String imgUrl;
    private String time;
    private String components;
    private String info;
    private String preps;

    public PizzaItem() {
        this.uid = counter++;
    }

    public PizzaItem(String label, double cost, String imgUrl, String time, String components, String info, String preps) {
        this.uid = counter++;
        this.label = label;
        this.cost = cost;
        this.imgUrl = imgUrl;
        this.time = time;
        this.components = components;
        this.info = info;
        this.preps = preps;
    }

    public long getUid() { return uid; }
    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }
    public double getCost() { return cost; }
    public void setCost(double cost) { this.cost = cost; }
    public String getImgUrl() { return imgUrl; }
    public void setImgUrl(String imgUrl) { this.imgUrl = imgUrl; }
    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
    public String getComponents() { return components; }
    public void setComponents(String components) { this.components = components; }
    public String getInfo() { return info; }
    public void setInfo(String info) { this.info = info; }
    public String getPreps() { return preps; }
    public void setPreps(String preps) { this.preps = preps; }

    @Override
    public String toString() {
        return label + " (" + cost + " USD)";
    }
}
