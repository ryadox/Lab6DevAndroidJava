package com.example.mypizzaapp.provider;

import com.example.mypizzaapp.entity.PizzaItem;
import com.example.mypizzaapp.repo.BaseDao;
import com.example.mypizzaapp.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DataStorage implements BaseDao<PizzaItem> {
    private static DataStorage manager;
    private final List<PizzaItem> items = new ArrayList<>();

    private DataStorage() {
        populate();
    }

    public static DataStorage getManager() {
        if (manager == null) manager = new DataStorage();
        return manager;
    }

    private void populate() {
        add(new PizzaItem("BBQ Chicken", 12.99, "res_bbq", "35m", "Chicken, BBQ Sauce, Onion", "Classic smoky flavor.", "1. Grill 2. Bake"));
        add(new PizzaItem("Green Delight", 10.50, "res_veg", "25m", "Spinach, Feta, Garlic", "Fresh and healthy.", "1. Prep 2. Melt"));
        add(new PizzaItem("Italian Classic", 14.00, "res_classic", "30m", "Mozzarella, Basil, Tomato", "The original taste.", "1. Slice 2. Bake"));
        add(new PizzaItem("Meat Lovers", 16.20, "res_classic", "45m", "Beef, Pepperoni, Bacon", "For the hungry ones.", "1. Cook 2. Stack"));
        add(new PizzaItem("Pesto Power", 13.00, "res_veg", "40m", "Pesto, Pine nuts, Parm", "Rich aromatic herb base.", "1. Spread 2. Crisp"));
        add(new PizzaItem("Spicy Veggie", 11.00, "res_veg", "20m", "Jalapeno, Corn, Peppers", "Heat in every bite.", "1. Chop 2. Spice"));
        add(new PizzaItem("Ocean Breeze", 15.50, "res_classic", "30m", "Shrimp, Garlic, Lemon", "Seafood luxury.", "1. Sauté 2. Top"));
        add(new PizzaItem("Cheese Bomb", 9.99, "res_bbq", "15m", "4 types of cheese", "Melty perfection.", "1. Layer 2. Broil"));
        add(new PizzaItem("Mushroom Magic", 12.00, "res_veg", "25m", "Truffle oil, Funghi", "Earthy and deep.", "1. Sauté 2. Bake"));
        add(new PizzaItem("Aloha", 11.50, "res_bbq", "30m", "Pineapple, Ham, Cheese", "Tropical controversial.", "1. Prep 2. Heat"));
    }

    @Override
    public PizzaItem add(PizzaItem obj) {
        items.add(obj);
        return obj;
    }

    @Override
    public PizzaItem edit(PizzaItem obj) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getUid() == obj.getUid()) {
                items.set(i, obj);
                return obj;
            }
        }
        return null;
    }

    @Override
    public boolean remove(long id) {
        return items.removeIf(p -> p.getUid() == id);
    }

    @Override
    public PizzaItem get(long id) {
        for (PizzaItem p : items) if (p.getUid() == id) return p;
        return null;
    }

    @Override
    public List<PizzaItem> getAll() {
        return Collections.unmodifiableList(items);
    }
}
