package com.example.mypizzaapp.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.mypizzaapp.R;
import com.example.mypizzaapp.adapter.PizzaItemAdapter;
import com.example.mypizzaapp.entity.PizzaItem;
import com.example.mypizzaapp.provider.DataStorage;
import java.util.List;

public class MainHubActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_list_pizzas);

        ListView feed = findViewById(R.id.pizzaListView);
        List<PizzaItem> collection = DataStorage.getManager().getAll();

        PizzaItemAdapter adapter = new PizzaItemAdapter(this, collection);
        feed.setAdapter(adapter);

        feed.setOnItemClickListener((adapterView, view, pos, id) -> {
            Intent screen = new Intent(this, InfoActivity.class);
            screen.putExtra("target_id", id);
            startActivity(screen);
        });
    }
}
